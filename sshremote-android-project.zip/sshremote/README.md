# SSH Remote — Personal SSH server for your own Android phone

A minimal Android app that runs a key-authenticated SSH server as a foreground
service, so you can `ssh` into your own phone's shell.

## How it works
- `MainActivity` — paste your **public** SSH key (never your private key) and
  pick a port, then start/stop the server.
- `SshService` — a foreground service running an embedded SSH server
  (Apache MINA SSHD). Authentication is public-key only — password login is
  disabled.
- `BootReceiver` — restarts the server automatically after the phone reboots.

## 1. Build the APK (no Android Studio needed)

This repo includes `.github/workflows/build.yml`. To build:

1. Push this folder to a new GitHub repository.
2. GitHub Actions will automatically run and build `app-debug.apk`.
3. Go to the repo's **Actions** tab → open the latest run → download the
   `ssh-remote-debug-apk` artifact.
4. Transfer the APK to your phone and install it (you'll need to allow
   "install unknown apps" for whichever app you use to open the file).

You can also trigger a build manually from the **Actions** tab using
"Run workflow" (workflow_dispatch).

## 2. On your computer: get your public key

```bash
cat ~/.ssh/id_ed25519.pub
# or, if you don't have a key yet:
ssh-keygen -t ed25519 -C "phone-access"
```

Copy the single line it prints (starts with `ssh-ed25519 ...`).

## 3. On the phone

1. Open the app, paste that public key line into the box, set a port
   (2222 by default — avoid 22, some ROMs reserve it), tap **Save Key + Port**.
2. Tap **Disable Battery Optimization** and allow it — otherwise Android
   will eventually suspend the service.
3. Tap **Start SSH Server**. The persistent notification confirms it's
   running.

## 4. Connect

If you're on the same WiFi network:
```bash
ssh -p 2222 -i ~/.ssh/id_ed25519 root@<phone-local-ip>
```
(The username doesn't matter — the authenticator only checks the key, not
the username field.)

For access from outside your home network, the phone's IP is usually
dynamic and behind NAT, so plain `ssh` won't reach it. Easiest fix:
install **Tailscale** on the phone (regular Play Store app) and connect
over its private IP instead of the public internet.

## Security notes
- Password auth is disabled — only the one public key you paste can log in.
- Keep your **private** key only on your computer, never pasted into the app.
- The shell is `/system/bin/sh`, so you get whatever permissions a normal
  app process has (not root, unless the phone is rooted and you explicitly
  grant it).
