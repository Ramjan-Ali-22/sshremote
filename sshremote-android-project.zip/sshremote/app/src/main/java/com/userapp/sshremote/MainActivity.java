package com.userapp.sshremote;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String PREFS = "ssh_remote_prefs";
    public static final String KEY_PUBKEY = "public_key";
    public static final String KEY_PORT = "port";

    private EditText editPublicKey;
    private EditText editPort;
    private TextView txtStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPublicKey = findViewById(R.id.editPublicKey);
        editPort = findViewById(R.id.editPort);
        txtStatus = findViewById(R.id.txtStatus);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        editPublicKey.setText(prefs.getString(KEY_PUBKEY, ""));
        editPort.setText(String.valueOf(prefs.getInt(KEY_PORT, 2222)));

        findViewById(R.id.btnSave).setOnClickListener(v -> {
            SharedPreferences.Editor ed = prefs.edit();
            ed.putString(KEY_PUBKEY, editPublicKey.getText().toString().trim());
            int port = 2222;
            try {
                port = Integer.parseInt(editPort.getText().toString().trim());
            } catch (NumberFormatException ignored) {
            }
            ed.putInt(KEY_PORT, port);
            ed.apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnStart).setOnClickListener(v -> {
            String key = prefs.getString(KEY_PUBKEY, "");
            if (key.isEmpty()) {
                Toast.makeText(this, "Save a public key first", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, SshService.class);
            startForegroundService(svc);
            txtStatus.setText("Status: starting...");
        });

        findViewById(R.id.btnStop).setOnClickListener(v -> {
            stopService(new Intent(this, SshService.class));
            txtStatus.setText("Status: stopped");
        });

        findViewById(R.id.btnBatteryExempt).setOnClickListener(v -> {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(this, "Already exempted", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
