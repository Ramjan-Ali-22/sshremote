package com.userapp.sshremote;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.apache.sshd.common.config.keys.AuthorizedKeyEntry;
import org.apache.sshd.server.SshServer;
import org.apache.sshd.server.auth.pubkey.PublickeyAuthenticator;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.server.shell.ProcessShellFactory;

import java.io.File;
import java.security.PublicKey;
import java.util.Collections;

public class SshService extends Service {

    private static final String TAG = "SshService";
    private static final String CHANNEL_ID = "ssh_remote_channel";
    private static final int NOTIF_ID = 1;

    private SshServer sshd;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification("starting..."));
        startSshServer();
        return START_STICKY;
    }

    private void startSshServer() {
        if (sshd != null && sshd.isStarted()) {
            return;
        }

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String authorizedKeyLine = prefs.getString(MainActivity.KEY_PUBKEY, "").trim();
        int port = prefs.getInt(MainActivity.KEY_PORT, 2222);

        if (authorizedKeyLine.isEmpty()) {
            Log.e(TAG, "No authorized public key saved, not starting server");
            stopSelf();
            return;
        }

        try {
            PublicKey authorizedKey = AuthorizedKeyEntry.parseAuthorizedKeyEntry(authorizedKeyLine)
                    .resolvePublicKey(null, Collections.emptyMap(), null);

            sshd = SshServer.setUpDefaultServer();
            sshd.setPort(port);

            File hostKeyFile = new File(getFilesDir(), "host_key.ser");
            sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider(hostKeyFile.toPath()));

            PublickeyAuthenticator authenticator = (username, key, session) ->
                    key.equals(authorizedKey);
            sshd.setPublickeyAuthenticator(authenticator);
            sshd.setPasswordAuthenticator(null);

            // Gives you a real shell (requires the device to have /system/bin/sh, which it does).
            // Root commands only work if the device is rooted and sh has su access.
            sshd.setShellFactory(new ProcessShellFactory(new String[]{"/system/bin/sh", "-i"}));

            sshd.start();
            Log.i(TAG, "SSH server started on port " + port);
            updateNotification("running on port " + port);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start SSH server", e);
            updateNotification("failed to start: " + e.getMessage());
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (sshd != null) {
            try {
                sshd.stop(true);
            } catch (Exception e) {
                Log.e(TAG, "Error stopping SSH server", e);
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "SSH Remote Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String status) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("SSH Remote")
                .setContentText("Status: " + status)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String status) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.notify(NOTIF_ID, buildNotification(status));
        }
    }
}
