package com.userapp.sshremote;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
            String key = prefs.getString(MainActivity.KEY_PUBKEY, "");
            if (!key.isEmpty()) {
                Intent svc = new Intent(context, SshService.class);
                ContextCompat.startForegroundService(context, svc);
            }
        }
    }
}
